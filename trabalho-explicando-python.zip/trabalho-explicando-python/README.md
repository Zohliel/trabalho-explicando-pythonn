# Trabalho Explicando o Python

Site educativo sobre Python, feito por **Arthur Fernandes, Lucas e Murilo** (SENAI).
Site publicado: https://zohliel.github.io/trabalho-explicando-python/

Este pacote contém o site exatamente como está publicado: o mesmo design, os mesmos exemplos, o símbolo do Python em 3D, o laboratório e os logotipos do Python e do SENAI.

## Como abrir no Windows (jeito mais simples)

1. Clique com o botão direito no arquivo `.zip` e escolha **Extrair tudo...**. Não abra o site de dentro do ZIP.
2. Abra a pasta extraída `trabalho-explicando-python`.
3. Dê dois cliques em **`abrir-site.bat`** (ou em **`index.html`**). O site abre no seu navegador.

Não é preciso instalar nada. O projeto é um único arquivo `index.html` com CSS, JavaScript e imagens embutidos, então **não usa React, Vite nem compilação**.

## Internet: o que precisa e o que acontece sem ela

Duas coisas são carregadas da internet quando você abre o site:

- **Fontes** (Manrope e JetBrains Mono, do Google Fonts). Sem internet, o navegador usa fontes parecidas do sistema.
- **three.js** (biblioteca do 3D, do cdnjs). Sem internet, o símbolo do Python aparece como imagem plana, sem rotação.

Todo o resto (textos, imagens, editor, laboratório, navegação) funciona offline. Para ver o site idêntico ao publicado, abra-o com internet.

## Servidor local (opcional)

Se quiser testar como em um servidor, instale o Python (https://www.python.org/downloads/) e dê dois cliques em `servidor-local.bat`. O site abrirá em http://localhost:8000. Feche a janela preta para parar.

## Publicar no GitHub Pages

1. No repositório `trabalho-explicando-python`, envie o conteúdo da pasta (o `index.html` precisa ficar na raiz) e o arquivo `.nojekyll`.
2. Em **Settings → Pages**, escolha a branch (por exemplo `main`) e a pasta `/ (root)`.
3. Aguarde alguns minutos e acesse o endereço do site.

O `index.html` usa só caminhos relativos e não depende de nenhum servidor, então funciona na publicação sem ajustes.

## Conteúdo da pasta

| Arquivo | Para que serve |
|---|---|
| `index.html` | O site completo. É o único arquivo necessário. |
| `abrir-site.bat` | Abre o site no navegador padrão. |
| `servidor-local.bat` | Abre o site por um servidor local (precisa do Python). |
| `.nojekyll` | Evita processamento do Jekyll no GitHub Pages. |
| `assets/imagens/` | Cópias das imagens, apenas para consulta. O site usa as imagens embutidas no `index.html`. |

## Observações

- O editor do Hello World é uma **simulação em JavaScript**: entende só `print`, variáveis, f-strings e escapes. Não é um interpretador Python completo.
- As fotos de Guido van Rossum e os logotipos foram enviados pela equipe. Confirme licença e atribuição antes de uso público.
- As marcas Python e SENAI pertencem aos seus respectivos titulares.
